from marshmallow import Schema


class CustomerSchemaOut(Schema):
    # Todo
    pass


class ShopOwnerSchemaOut(Schema):
    # Todo
    pass
